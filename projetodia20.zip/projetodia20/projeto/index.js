const express = require('express')
const path = require('path');
const app = express();
const port = 3000

app.use(express.static('public'));

app.get('/index', (req, res) => {
  res.sendFile(path.join(__dirname, '/index.html'));
})
app.get('/formacao-academica', (req, res) => {
  res.sendFile(path.join(__dirname, '/formacao-academica.html'));
})

app.get('/projetos', (req, res) => {
  res.sendFile(path.join(__dirname, '/projetos.html'));
})

app.listen(port, () => {
  console.log(`ROGER ROGER, Servidor funcionando na porta:${port}`)
})

